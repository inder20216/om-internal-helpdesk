import React, { useState, useEffect } from 'react';
import { useMsal } from '@azure/msal-react';
import { Bell, Calendar, TrendingUp, Clock, Edit3 } from 'lucide-react';
import { PieChart, Pie, BarChart, Bar, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { format, subDays } from 'date-fns';
import toast, { Toaster } from 'react-hot-toast';
import sharepointService from '../services/sharepointService';
import { loginRequest } from '../config/authConfig';
import StatusDetailsModal from './StatusDetailsModal';

// Exact colors from HTML
const COLORS = {
  priority: ['#EF4444', '#F59E0B', '#10B981'], // Red, Orange, Green
  status: ['#3B82F6', '#F59E0B', '#8B5CF6', '#A855F7', '#10B981', '#6B7280'], // Blue, Orange, Purple, etc.
  reasons: '#06B6D4' // Cyan for bar chart
};

// Custom label for pie charts with white text
const renderCustomLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent, name }) => {
  const RADIAN = Math.PI / 180;
  const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
  const x = cx + radius * Math.cos(-midAngle * RADIAN);
  const y = cy + radius * Math.sin(-midAngle * RADIAN);

  if (percent < 0.05) return null; // Don't show labels for very small slices

  return (
    <text 
      x={x} 
      y={y} 
      fill="white" 
      textAnchor={x > cx ? 'start' : 'end'} 
      dominantBaseline="central"
      className="text-xs font-semibold"
      style={{ textShadow: '2px 2px 4px rgba(0,0,0,0.9)' }}
    >
      {`${name} (${(percent * 100).toFixed(0)}%)`}
    </text>
  );
};

const Dashboard = ({ department }) => {
  const { instance, accounts } = useMsal();
  const [tickets, setTickets] = useState([]);
  const [filteredTickets, setFilteredTickets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newTicketCount, setNewTicketCount] = useState(0);
  
  // Filters
  const [startDate, setStartDate] = useState(format(subDays(new Date(), 30), 'yyyy-MM-dd'));
  const [endDate, setEndDate] = useState(format(new Date(), 'yyyy-MM-dd'));

  // Modal state
  const [statusDetailsModal, setStatusDetailsModal] = useState({
    isOpen: false,
    ticket: null
  });

  // Stats
  const [stats, setStats] = useState({
    total: 0,
    avgResolution: '0',
    byPriority: [],
    byReason: [],
    byStatus: []
  });

  // Fetch data
  const fetchData = async () => {
    try {
      const response = await instance.acquireTokenSilent({
        ...loginRequest,
        account: accounts[0],
      });
      
      sharepointService.setAccessToken(response.accessToken);
      
      const data = await sharepointService.getTickets({
        department: department,
        startDate,
        endDate
      });

      // Check for new tickets
      const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
      const newTickets = data.filter(t => new Date(t.createdDate) > fiveMinutesAgo);
      if (newTickets.length > newTicketCount) {
        toast.success(`${newTickets.length} new ticket(s) received!`, {
          icon: '🔔',
          duration: 5000,
        });
      }
      setNewTicketCount(newTickets.length);

      setTickets(data);
      setFilteredTickets(data);
      calculateStats(data);
      
      setLoading(false);
    } catch (error) {
      console.error('Error:', error);
      toast.error('Failed to load tickets');
      setLoading(false);
    }
  };

  useEffect(() => {
    if (accounts.length > 0) {
      fetchData();
      const interval = setInterval(fetchData, 30000); // Refresh every 30 seconds
      return () => clearInterval(interval);
    }
  }, [accounts, startDate, endDate, department]);

  // Calculate statistics
  const calculateStats = (data) => {
    setStats({
      total: data.length,
      avgResolution: sharepointService.calculateAvgResolutionTime(data),
      byPriority: sharepointService.groupTicketsByCategory(data, 'priority'),
      byReason: sharepointService.groupTicketsByCategory(data, 'ticketReason').slice(0, 5),
      byStatus: sharepointService.groupTicketsByCategory(data, 'status')
    });
  };

  // Handle status update
  const handleStatusUpdate = async (ticketId, newStatus) => {
    try {
      await sharepointService.updateTicketStatus(ticketId, newStatus);
      toast.success('Status updated successfully!');
      fetchData();
    } catch (error) {
      toast.error('Failed to update status');
    }
  };

  // Handle status details update
  const handleStatusDetailsUpdate = async (ticketId, statusDetails) => {
    try {
      await sharepointService.updateStatusDetails(ticketId, statusDetails);
      toast.success('Status details updated successfully!');
      fetchData();
    } catch (error) {
      toast.error('Failed to update status details');
      throw error;
    }
  };

  // Open/Close modal
  const openStatusDetailsModal = (ticket) => {
    setStatusDetailsModal({ isOpen: true, ticket: ticket });
  };

  const closeStatusDetailsModal = () => {
    setStatusDetailsModal({ isOpen: false, ticket: null });
  };

  // Priority badge color
  const getPriorityColor = (priority) => {
    switch (priority?.toLowerCase()) {
      case 'high': return 'bg-red-500 bg-opacity-20 text-red-400 border border-red-500';
      case 'normal': return 'bg-orange-500 bg-opacity-20 text-orange-400 border border-orange-500';
      case 'low': return 'bg-green-500 bg-opacity-20 text-green-400 border border-green-500';
      default: return 'bg-gray-500 bg-opacity-20 text-gray-400 border border-gray-500';
    }
  };

  // Status badge color
  const getStatusColor = (status) => {
    const statusLower = status?.toLowerCase();
    if (statusLower === 'resolved' || statusLower === 'closed') {
      return 'bg-green-500 bg-opacity-20 text-green-400 border border-green-500';
    } else if (statusLower === 'in progress' || statusLower?.includes('progress')) {
      return 'bg-orange-500 bg-opacity-20 text-orange-400 border border-orange-500';
    } else if (statusLower === 'pending' || statusLower?.includes('observation')) {
      return 'bg-purple-500 bg-opacity-20 text-purple-400 border border-purple-500';
    } else if (statusLower === 'open') {
      return 'bg-blue-500 bg-opacity-20 text-blue-400 border border-blue-500';
    }
    return 'bg-gray-500 bg-opacity-20 text-gray-400 border border-gray-500';
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-cyan-400 mx-auto"></div>
          <p className="mt-4 text-gray-300">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <Toaster position="top-right" />
      
      {/* Header */}
      <div className="bg-slate-800 bg-opacity-90 backdrop-blur-sm shadow-xl border-b border-slate-700">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-white">IT Helpdesk Dashboard</h1>
              <p className="text-sm text-slate-400 mt-1">
                Powered by Open Mind Services Limited
              </p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Bell className="w-6 h-6 text-cyan-400 cursor-pointer hover:text-cyan-300" />
                {newTicketCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {newTicketCount}
                  </span>
                )}
              </div>
              <div className="text-right">
                <p className="text-sm font-medium text-white">{accounts[0]?.name}</p>
                <p className="text-xs text-slate-400">{accounts[0]?.username}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-6">
        {/* Filters - Compact */}
        <div className="bg-slate-800 bg-opacity-50 backdrop-blur-sm border border-slate-700 rounded-lg shadow-lg p-3 mb-6">
          <div className="flex items-center gap-6">
            <Calendar className="w-5 h-5 text-cyan-400 flex-shrink-0" />
            <div className="flex items-center gap-3">
              <label className="text-sm text-slate-300 whitespace-nowrap">Start Date</label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="px-3 py-1.5 bg-slate-700 border border-slate-600 text-white text-sm rounded focus:ring-2 focus:ring-cyan-500 focus:outline-none"
              />
            </div>
            <div className="flex items-center gap-3">
              <label className="text-sm text-slate-300 whitespace-nowrap">End Date</label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="px-3 py-1.5 bg-slate-700 border border-slate-600 text-white text-sm rounded focus:ring-2 focus:ring-cyan-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Department Stats Card - Blue Gradient like HTML */}
        <div className="mb-6">
          <div className="bg-gradient-to-r from-blue-600 to-cyan-500 rounded-2xl shadow-2xl p-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-3xl font-bold text-white">{department}</h3>
              <TrendingUp className="w-10 h-10 text-white opacity-80" />
            </div>
            <div className="grid grid-cols-2 gap-8">
              <div>
                <p className="text-sm text-white opacity-90 mb-2">Total Tickets</p>
                <p className="text-5xl font-bold text-white">{stats.total}</p>
              </div>
              <div>
                <p className="text-sm text-white opacity-90 mb-2">Avg Resolution Time</p>
                <p className="text-5xl font-bold text-white flex items-center gap-3">
                  <Clock className="w-10 h-10" />
                  {stats.avgResolution}h
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Charts - Clean boxes like HTML */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          {/* Priority Chart */}
          <div className="bg-slate-800 bg-opacity-80 backdrop-blur-sm border border-slate-700 rounded-xl shadow-xl p-6">
            <h3 className="text-lg font-bold text-white mb-6">Tickets by Priority</h3>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={stats.byPriority}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={renderCustomLabel}
                  outerRadius={90}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {stats.byPriority.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS.priority[index % COLORS.priority.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1e293b', 
                    border: '1px solid #475569',
                    borderRadius: '8px',
                    color: '#fff'
                  }} 
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Status Chart */}
          <div className="bg-slate-800 bg-opacity-80 backdrop-blur-sm border border-slate-700 rounded-xl shadow-xl p-6">
            <h3 className="text-lg font-bold text-white mb-6">Tickets by Status</h3>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={stats.byStatus}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={renderCustomLabel}
                  outerRadius={90}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {stats.byStatus.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS.status[index % COLORS.status.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1e293b', 
                    border: '1px solid #475569',
                    borderRadius: '8px',
                    color: '#fff'
                  }} 
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Top Reasons Bar Chart */}
          <div className="bg-slate-800 bg-opacity-80 backdrop-blur-sm border border-slate-700 rounded-xl shadow-xl p-6">
            <h3 className="text-lg font-bold text-white mb-6">Top Ticket Reasons</h3>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={stats.byReason} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis type="number" stroke="#94a3b8" />
                <YAxis 
                  dataKey="name" 
                  type="category" 
                  width={120} 
                  stroke="#94a3b8" 
                  style={{ fontSize: '11px' }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1e293b', 
                    border: '1px solid #475569',
                    borderRadius: '8px',
                    color: '#fff'
                  }} 
                />
                <Bar dataKey="value" fill={COLORS.reasons} radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Recent Tickets Table */}
        <div className="bg-slate-800 bg-opacity-80 backdrop-blur-sm border border-slate-700 rounded-xl shadow-xl overflow-hidden">
          <div className="px-6 py-4 bg-gradient-to-r from-cyan-600 to-blue-600 text-white flex items-center justify-between">
            <h3 className="text-xl font-bold">Recent Tickets</h3>
            <span className="bg-slate-900 text-cyan-400 px-4 py-2 rounded-full text-sm font-bold">
              {filteredTickets.length} tickets
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-900">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-bold text-slate-400 uppercase tracking-wider">TICKET</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-slate-400 uppercase tracking-wider">REASON</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-slate-400 uppercase tracking-wider">PRIORITY</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-slate-400 uppercase tracking-wider">STATUS</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-slate-400 uppercase tracking-wider">STATUS DETAILS</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-slate-400 uppercase tracking-wider">TICKET RAISED BY</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-slate-400 uppercase tracking-wider">DATE</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700">
                {filteredTickets.slice(0, 50).map((ticket) => (
                  <tr key={ticket.id} className="hover:bg-slate-700 hover:bg-opacity-50 transition-colors">
                    <td className="px-6 py-4 text-sm font-medium text-white">
                      {ticket.ticketTitle || ticket.title}
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-300">
                      {ticket.ticketReason}
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-3 py-1 rounded-full text-xs font-bold ${getPriorityColor(ticket.priority)}`}>
                        {ticket.priority}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <select
                        value={ticket.status}
                        onChange={(e) => handleStatusUpdate(ticket.id, e.target.value)}
                        className={`px-3 py-1 rounded-full text-xs font-bold cursor-pointer ${getStatusColor(ticket.status)} focus:outline-none focus:ring-2 focus:ring-cyan-500`}
                      >
                        <option>Open</option>
                        <option>In Progress</option>
                        <option>Pending</option>
                        <option>Partially Resolved - Under Observation</option>
                        <option>Resolved</option>
                        <option>Closed</option>
                      </select>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-300">
                      <div className="flex items-center gap-2">
                        <span className="truncate max-w-xs">
                          {ticket.statusDetails || 'No details'}
                        </span>
                        <button
                          onClick={() => openStatusDetailsModal(ticket)}
                          className="text-cyan-400 hover:text-cyan-300 transition-colors flex-shrink-0"
                          title="Edit status details"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-300">
                      {ticket.TicketRaisedBy || ticket.ticketRaisedBy || '-'}
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-300">
                      {format(new Date(ticket.createdDate), 'dd-MM-yyyy')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Status Details Modal */}
      <StatusDetailsModal
        ticket={statusDetailsModal.ticket}
        isOpen={statusDetailsModal.isOpen}
        onClose={closeStatusDetailsModal}
        onSave={handleStatusDetailsUpdate}
      />
    </div>
  );
};

export default Dashboard;