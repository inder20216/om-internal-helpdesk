import axios from 'axios';

class SharePointService {
  constructor() {
    this.siteId = null;
    this.listId = null;
    this.accessToken = null;
  }

  setAccessToken(token) {
    this.accessToken = token;
  }

  getHeaders() {
    return {
      'Authorization': `Bearer ${this.accessToken}`,
      'Content-Type': 'application/json',
    };
  }

  // Get Site ID
  async getSiteId() {
    if (this.siteId) return this.siteId;

    try {
      const hostname = 'openmindservices.sharepoint.com';
      const sitePath = '/sites/InternalHelpdesk';
      
      const url = `https://graph.microsoft.com/v1.0/sites/${hostname}:${sitePath}`;
      const response = await axios.get(url, { headers: this.getHeaders() });
      
      this.siteId = response.data.id;
      return this.siteId;
    } catch (error) {
      console.error('Error getting site ID:', error);
      throw error;
    }
  }

  // Get List ID
  async getListId() {
    if (this.listId) return this.listId;

    try {
      const siteId = await this.getSiteId();
      const url = `https://graph.microsoft.com/v1.0/sites/${siteId}/lists?$filter=displayName eq 'Tickets Management'`;
      
      const response = await axios.get(url, { headers: this.getHeaders() });
      
      if (response.data.value && response.data.value.length > 0) {
        this.listId = response.data.value[0].id;
        return this.listId;
      }
      throw new Error('List not found');
    } catch (error) {
      console.error('Error getting list ID:', error);
      throw error;
    }
  }

 // Fetch all tickets with filters
  async getTickets(filters = {}) {
    try {
      const siteId = await this.getSiteId();
      const listId = await this.getListId();
      
      let url = `https://graph.microsoft.com/v1.0/sites/${siteId}/lists/${listId}/items?$expand=fields&$top=1000`;
      
      const response = await axios.get(url, { headers: this.getHeaders() });
      
      let tickets = response.data.value.map(item => ({
        id: item.id,
        title: item.fields.Title,
        ticketTitle: item.fields.TicketTitle || item.fields.Title,
        createdDate: item.fields.Created || item.createdDateTime,
        department: item.fields.Department,
        ticketReason: item.fields.TicketReason,
        ticketRaisedBy: item.fields.TicketRaisedBy || item.fields.Ticket_x0020_Raised_x0020_By || '',
        priority: item.fields.Priority,
        status: item.fields.Status,
        statusDetails: item.fields.StatusDetails || '',
        modifiedDate: item.fields.Modified || item.lastModifiedDateTime,
        ...item.fields
      }));

      // Apply filters
      if (filters.department) {
        tickets = tickets.filter(t => t.department === filters.department);
      }

      if (filters.startDate) {
        const startDate = new Date(filters.startDate);
        tickets = tickets.filter(t => new Date(t.createdDate) >= startDate);
      }

      if (filters.endDate) {
        const endDate = new Date(filters.endDate);
        endDate.setHours(23, 59, 59);
        tickets = tickets.filter(t => new Date(t.createdDate) <= endDate);
      }

      // Sort by created date descending
      tickets.sort((a, b) => new Date(b.createdDate) - new Date(a.createdDate));

      return tickets;
    } catch (error) {
      console.error('Error fetching tickets:', error);
      throw error;
    }
  }

  // Update ticket status
  async updateTicketStatus(ticketId, newStatus) {
    try {
      const siteId = await this.getSiteId();
      const listId = await this.getListId();
      
      const url = `https://graph.microsoft.com/v1.0/sites/${siteId}/lists/${listId}/items/${ticketId}/fields`;
      
      await axios.patch(url, {
        Status: newStatus
      }, {
        headers: this.getHeaders()
      });

      return { success: true };
    } catch (error) {
      console.error('Error updating ticket status:', error);
      throw error;
    }
  }

  // Update ticket status details
  async updateStatusDetails(ticketId, statusDetails) {
    try {
      const siteId = await this.getSiteId();
      const listId = await this.getListId();
      
      const url = `https://graph.microsoft.com/v1.0/sites/${siteId}/lists/${listId}/items/${ticketId}/fields`;
      
      await axios.patch(url, {
        StatusDetails: statusDetails
      }, {
        headers: this.getHeaders()
      });

      return { success: true };
    } catch (error) {
      console.error('Error updating status details:', error);
      throw error;
    }
  }

  // Calculate average resolution time (Created to Resolved)
  calculateAvgResolutionTime(tickets) {
    const resolvedTickets = tickets.filter(t => 
      t.status === 'Resolved' && t.createdDate && t.modifiedDate
    );

    if (resolvedTickets.length === 0) return '0';

    const totalHours = resolvedTickets.reduce((sum, ticket) => {
      const created = new Date(ticket.createdDate);
      const resolved = new Date(ticket.modifiedDate);
      const hours = (resolved - created) / (1000 * 60 * 60);
      return sum + hours;
    }, 0);

    return (totalHours / resolvedTickets.length).toFixed(1);
  }

  // Get tickets grouped by category
  groupTicketsByCategory(tickets, category) {
    const grouped = {};
    tickets.forEach(ticket => {
      const key = ticket[category.toLowerCase()] || 'Unknown';
      grouped[key] = (grouped[key] || 0) + 1;
    });
    return Object.entries(grouped).map(([name, value]) => ({ name, value }));
  }
}

export default new SharePointService();